<?php
//START SESSION FOR HOLDING SESSION VARIABLES
if(!isset($_SESSION)){session_start();}

?>